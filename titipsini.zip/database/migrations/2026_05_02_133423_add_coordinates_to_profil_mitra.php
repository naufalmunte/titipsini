<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
public function up()
{
    Schema::table('profil_mitra', function (Blueprint $table) {
        $table->string('latitude')->nullable()->after('alamat');
        $table->string('longitude')->nullable()->after('latitude');
    });
}

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('profil_mitra', function (Blueprint $table) {
            //
        });
    }
};
